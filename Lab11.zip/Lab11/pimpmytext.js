alert("Hello World!");

window.onload = function() {
	document.getElementById("pimp").onclick = increaseFont;
	document.getElementById("bling").onchange = blingin;
	document.getElementById("snoop").onclick = snoopin;
};

function increaseFont() {
	var text = document.getElementById("text");
	text.style.fontSize = "24pt";
}

function blingin() {
	var text = document.getElementById("text");
	if (document.getElementById("bling").checked) {
		text.style.fontWeight = "bold";
		text.style.color = "green";
		text.style.textDecoration = "underline blink";
		text.style.fontFamily = "Times New Roman";
	} else {
		text.style.fontWeight = "normal";
		text.style.color = "black";
		text.style.textDecoration = "none";
	}
}

function snoopin() {
	var text = document.getElementById("text");
	var array = text.value.split(".");
	text.value = array.join("-izzle.");
}